import React from 'react'

const Listing = () => {
  return (
    <div className=' bg-[#6358DC] p-8'>Listing</div>
  )
}

export default Listing