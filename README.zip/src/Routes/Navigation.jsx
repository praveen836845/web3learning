import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from '../Home/Home'
import Login from '../Pages/Login';
import Header from '../Pages/Header';
import Listing from '../Pages/Listing';


const Navigation = () => {
  return (
    <>
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/login' element={<Login />} />
          <Route path='/listing' element={<Listing />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default Navigation